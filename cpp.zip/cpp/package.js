let navbar = document.querySelector('.navbar');

window.onscroll = () =>{
	navbar.classList.remove('active');
}
menu.addEventListener('click', () =>{
    navbar.classList.toggle('active');
});